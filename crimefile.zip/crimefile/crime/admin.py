from django.contrib import admin
from .models import Newuser,Addnews,Addmissing,Addwanted,Addfir,Addregister, Addhistory, Addcom2,Addcrime,Addmessage
admin.site.register(Newuser)
admin.site.register(Addnews)
admin.site.register(Addmissing)
admin.site.register(Addwanted)
admin.site.register(Addfir)
admin.site.register(Addregister)
admin.site.register(Addhistory)
admin.site.register(Addcom2)
admin.site.register(Addcrime)
admin.site.register(Addmessage)



# Register your models here.
