from django.apps import AppConfig


class CrimeConfig(AppConfig):
    name = 'crime'
